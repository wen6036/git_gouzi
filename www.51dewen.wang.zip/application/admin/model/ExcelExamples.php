<?php
/**
 * 后台excel导入导出示例模型
 * @author yupoxiong<i@yufuping.com>
 */


namespace app\admin\model;

class ExcelExamples extends Admin
{
    protected $name = 'excel_examples';
}

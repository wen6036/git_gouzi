<?php
/**
 * 后台菜单模型
 * @author yupoxiong<i@yufuping.com>
 */

namespace app\admin\model;

class AdminMenus extends Admin
{
    protected $name = 'admin_menus';
}
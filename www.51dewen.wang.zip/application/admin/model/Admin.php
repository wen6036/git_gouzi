<?php
/**
 * 后台模型父类
 * @author yupoxiong<i@yufuping.com>
 * Date: 2018/5/20
 */

namespace app\admin\model;

use app\common\model\Model;

class Admin extends Model
{

}
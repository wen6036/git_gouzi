<?php
/**
 * 模型公共类
 * @author yupoxiong<i@yufuping.com>
 */

namespace app\common\model;

use think\Model as ThinkModel;

class Model extends ThinkModel
{

}

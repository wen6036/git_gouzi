<?php
/**
 * Api模块英文语言文件
 * @author yupoxiong<i@yufuping.com>
 */

return [
    'miss token'    => 'miss token',
    'Api not found' => '404 not found',
    'token error' => 'token error',

    //user验证
    'account_require'=>'Account cannot be empty',
    'account_max'=>'Account can not exceed 25 characters',
    'password_require'=>'Password cannot be empty',
    'password_between'=>'Password is 6-16 characters in length',
];

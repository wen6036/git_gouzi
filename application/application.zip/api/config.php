<?php
/**
 * @author yupoxiong<i@yufuping.com>
 */

return [
    'default_return_type' => 'json',
];
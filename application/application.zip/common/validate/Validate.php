<?php
/**
 * 验证公共类
 * @author yupoxiong<i@yufuping.com>
 * Date: 2018/5/20
 */
namespace app\common\validate;

use think\Validate as ThinkValidate;

class Validate extends ThinkValidate
{

}
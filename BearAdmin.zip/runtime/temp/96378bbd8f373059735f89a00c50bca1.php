<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:91:"D:\phpStudy\PHPTutorial\WWW\BearAdmin\public/../application/admin\view\admin_file\view.html";i:1554946956;}*/ ?>

<link rel="stylesheet" href="/static/admin/css/app.min.css">
<script src="/static/admin/js/app.min.js"></script>
<div class="row">
    <div class="col-md-6">
        <div class="box box-solid">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo $info['original_name']; ?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <img src="<?php echo $info['thumbnail']; ?>" alt="预览图" style="max-height: 120px;max-width: 120px;">
            </div>
            <!-- /.box-body -->
        </div>
    </div>
    <!-- /.col -->
    <div class="col-md-6">
        <div class="box box-solid">
            <div class="box-body">
                <dl class="dl-horizontal">
                    <dt>ID :</dt>
                    <dd><?php echo $info['id']; ?></dd>
                    <dt>名称：</dt>
                    <dd><?php echo $info['original_name']; ?></dd>
                    <dt>类型：</dt>
                    <dd><?php echo $info['file_type']; ?></dd>
                    <dt>url：</dt>
                    <dd><a href="<?php echo $info['file_url']; ?>" target="_blank"><?php echo $info['file_url']; ?></a> </dd>
                    <dt>时间：</dt>
                    <dd><?php echo $info['create_time']; ?></dd>
                </dl>
            </div>
            <!-- /.box-body -->
        </div>
    </div>
    <!-- /.col -->
</div>

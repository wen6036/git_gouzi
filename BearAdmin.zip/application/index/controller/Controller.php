<?php
/**
 * @author yupoxiong<i@yufuping.com>
 * 前台基础控制器
 */
namespace app\index\controller;

use think\Controller as Tk;

class Controller extends Tk
{

    
}
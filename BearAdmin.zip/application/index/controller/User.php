<?php
/**
 * 用户中心
 * @author yupoxiong<i@yufuping.com>
 */
namespace app\index\controller;

class User
{
    public function index(){
        return 'user';
    }
}
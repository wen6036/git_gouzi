<?php
/**
 * 后台验证父类
 * @author yupoxiong<i@yufuping.com>
 */

namespace app\admin\validate;

use app\common\validate\Validate;

class Admin extends Validate
{

}